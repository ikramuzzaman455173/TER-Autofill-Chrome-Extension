// Add an event listener to the "Apply and Submit" button
document.getElementById('applyAndSubmit').addEventListener('click', () => {
  // Get values from the popup input fields
  const selectValue = document.getElementById('selectValue').value || "Agree";
  const likeText = document.getElementById('likeText').value || "Very knowledgeable and engaging.";
  const dislikeText = document.getElementById('dislikeText').value || "No specific feedback to share.";

  // Query the active tab and inject the autofill logic
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      args: [selectValue, likeText, dislikeText],
      func: (selectValue, likeText, dislikeText) => {
        // Autofill dropdowns
        const dropdowns = document.querySelectorAll('select');
        dropdowns.forEach((dropdown) => {
          Array.from(dropdown.options).forEach((option) => {
            if (option.textContent.trim() === selectValue) {
              dropdown.value = option.value;
            }
          });
        });

        // Autofill "like" and "dislike" text areas
        const textAreas = document.querySelectorAll('textarea');
        if (textAreas.length >= 2) {
          textAreas[0].value = likeText;
          textAreas[1].value = dislikeText;
        } else {
          console.error("Textareas for 'like' and 'dislike' not found.");
        }
      },
    });
  });
});

